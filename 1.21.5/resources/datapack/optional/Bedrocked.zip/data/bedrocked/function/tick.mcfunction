execute as @e[type=armor_stand,nbt=!{ShowArms:1b}] run data merge entity @s {ShowArms:1b}
execute in minecraft:the_nether as @a[distance=0..,predicate=bedrocked:y128] run damage @s 2