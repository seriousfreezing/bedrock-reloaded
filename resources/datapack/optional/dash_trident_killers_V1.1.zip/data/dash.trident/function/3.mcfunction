##Compiled with Dash Datapack Compiler (brace-delimited).


execute store result score @s dash.trident_owner.0 run data get entity @s Owner[0]
execute store result score @s dash.trident_owner.1 run data get entity @s Owner[1]
execute store result score @s dash.trident_owner.2 run data get entity @s Owner[2]
execute store result score @s dash.trident_owner.3 run data get entity @s Owner[3]

tag @s add dash.trident_has.owner
