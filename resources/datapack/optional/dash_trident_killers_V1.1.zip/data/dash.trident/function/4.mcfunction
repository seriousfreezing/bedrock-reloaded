##Compiled with Dash Datapack Compiler (brace-delimited).


execute store result score @s dash.trident_uuid.0 run data get entity @s UUID[0]
execute store result score @s dash.trident_uuid.1 run data get entity @s UUID[1]
execute store result score @s dash.trident_uuid.2 run data get entity @s UUID[2]
execute store result score @s dash.trident_uuid.3 run data get entity @s UUID[3]

tag @s add dash.trident_has.uuid
