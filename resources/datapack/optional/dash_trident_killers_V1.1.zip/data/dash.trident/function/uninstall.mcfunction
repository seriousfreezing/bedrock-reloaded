##Compiled with Dash Datapack Compiler (brace-delimited).


scoreboard objectives remove dash.trident_dam.cd

scoreboard objectives remove dash.trident_uuid.0
scoreboard objectives remove dash.trident_uuid.1
scoreboard objectives remove dash.trident_uuid.2
scoreboard objectives remove dash.trident_uuid.3

scoreboard objectives remove dash.trident_owner.0
scoreboard objectives remove dash.trident_owner.1
scoreboard objectives remove dash.trident_owner.2
scoreboard objectives remove dash.trident_owner.3

tag @a remove dash.trident_has.uuid

tellraw @a ["",{"text":"Successfully Uninstalled ","color":"gray"},{"text":"\"Dash Java Trident Killer\"","color":"yellow"},{"text":" add-on","color":"gray"}]
