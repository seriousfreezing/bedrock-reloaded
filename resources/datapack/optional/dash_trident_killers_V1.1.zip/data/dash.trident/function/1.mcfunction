##Compiled with Dash Datapack Compiler (brace-delimited).


scoreboard objectives add dash.trident_dam.cd dummy

scoreboard objectives add dash.trident_uuid.0 dummy
scoreboard objectives add dash.trident_uuid.1 dummy
scoreboard objectives add dash.trident_uuid.2 dummy
scoreboard objectives add dash.trident_uuid.3 dummy

scoreboard objectives add dash.trident_owner.0 dummy
scoreboard objectives add dash.trident_owner.1 dummy
scoreboard objectives add dash.trident_owner.2 dummy
scoreboard objectives add dash.trident_owner.3 dummy
