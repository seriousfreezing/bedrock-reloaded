##Compiled with Dash Datapack Compiler (brace-delimited).


execute as @e[type=minecraft:trident] at @s if block ~ ~ ~ minecraft:moving_piston run function dash.trident:0

execute as @e[type=minecraft:trident,tag=dash.trident_has.owner] at @s run data merge entity @s {life:0}
