##Compiled with Dash Datapack Compiler (brace-delimited).


execute as @a at @s if entity @s[tag=!dash.trident_has.uuid] run function dash.trident:4
execute if entity @s[tag=!dash.trident_has.owner] run function dash.trident:3

tag @s add dash.trident_tri.searching
execute as @a at @s if score @s dash.trident_uuid.0 = @n[tag=dash.trident_tri.searching] dash.trident_owner.0 if score @s dash.trident_uuid.1 = @n[tag=dash.trident_tri.searching] dash.trident_owner.1 if score @s dash.trident_uuid.2 = @n[tag=dash.trident_tri.searching] dash.trident_owner.2 if score @s dash.trident_uuid.3 = @n[tag=dash.trident_tri.searching] dash.trident_owner.3 run tag @s add dash.trident_tri.owner
execute as @e[type=!#dash.trident:nondamagable,distance=..1,limit=1,sort=random] at @s run damage @s 8 minecraft:trident by @n[tag=dash.trident_tri.owner]
execute if entity @e[tag=!dash.trident_tri.owner] run execute as @e[type=!#dash.trident:nondamagable,distance=..1,limit=1,sort=random] at @s run damage @s 8 minecraft:trident
tag @n[tag=dash.trident_tri.owner] remove dash.trident_tri.owner
tag @s add dash.trident_tri.searching

data merge entity @s {life:0}

playsound minecraft:item.trident.hit player @a ~ ~ ~ 1
