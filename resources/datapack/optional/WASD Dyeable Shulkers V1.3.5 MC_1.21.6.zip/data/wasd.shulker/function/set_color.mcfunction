execute if entity @e[type=item,tag=!wasd.validated,distance=..0.0001,sort=nearest,limit=1,nbt={Item:{id:"minecraft:white_dye"}}] run data merge entity @s {Color:0b,Tags:["wasd.color_changed"]}
execute if entity @e[type=item,tag=!wasd.validated,distance=..0.0001,sort=nearest,limit=1,nbt={Item:{id:"minecraft:orange_dye"}}] run data merge entity @s {Color:1b,Tags:["wasd.color_changed"]}
execute if entity @e[type=item,tag=!wasd.validated,distance=..0.0001,sort=nearest,limit=1,nbt={Item:{id:"minecraft:magenta_dye"}}] run data merge entity @s {Color:2b,Tags:["wasd.color_changed"]}
execute if entity @e[type=item,tag=!wasd.validated,distance=..0.0001,sort=nearest,limit=1,nbt={Item:{id:"minecraft:light_blue_dye"}}] run data merge entity @s {Color:3b,Tags:["wasd.color_changed"]}
execute if entity @e[type=item,tag=!wasd.validated,distance=..0.0001,sort=nearest,limit=1,nbt={Item:{id:"minecraft:yellow_dye"}}] run data merge entity @s {Color:4b,Tags:["wasd.color_changed"]}
execute if entity @e[type=item,tag=!wasd.validated,distance=..0.0001,sort=nearest,limit=1,nbt={Item:{id:"minecraft:lime_dye"}}] run data merge entity @s {Color:5b,Tags:["wasd.color_changed"]}
execute if entity @e[type=item,tag=!wasd.validated,distance=..0.0001,sort=nearest,limit=1,nbt={Item:{id:"minecraft:pink_dye"}}] run data merge entity @s {Color:6b,Tags:["wasd.color_changed"]}
execute if entity @e[type=item,tag=!wasd.validated,distance=..0.0001,sort=nearest,limit=1,nbt={Item:{id:"minecraft:gray_dye"}}] run data merge entity @s {Color:7b,Tags:["wasd.color_changed"]}
execute if entity @e[type=item,tag=!wasd.validated,distance=..0.0001,sort=nearest,limit=1,nbt={Item:{id:"minecraft:light_gray_dye"}}] run data merge entity @s {Color:8b,Tags:["wasd.color_changed"]}
execute if entity @e[type=item,tag=!wasd.validated,distance=..0.0001,sort=nearest,limit=1,nbt={Item:{id:"minecraft:cyan_dye"}}] run data merge entity @s {Color:9b,Tags:["wasd.color_changed"]}
execute if entity @e[type=item,tag=!wasd.validated,distance=..0.0001,sort=nearest,limit=1,nbt={Item:{id:"minecraft:purple_dye"}}] run data merge entity @s {Color:10b,Tags:["wasd.color_changed"]}
execute if entity @e[type=item,tag=!wasd.validated,distance=..0.0001,sort=nearest,limit=1,nbt={Item:{id:"minecraft:blue_dye"}}] run data merge entity @s {Color:11b,Tags:["wasd.color_changed"]}
execute if entity @e[type=item,tag=!wasd.validated,distance=..0.0001,sort=nearest,limit=1,nbt={Item:{id:"minecraft:brown_dye"}}] run data merge entity @s {Color:12b,Tags:["wasd.color_changed"]}
execute if entity @e[type=item,tag=!wasd.validated,distance=..0.0001,sort=nearest,limit=1,nbt={Item:{id:"minecraft:green_dye"}}] run data merge entity @s {Color:13b,Tags:["wasd.color_changed"]}
execute if entity @e[type=item,tag=!wasd.validated,distance=..0.0001,sort=nearest,limit=1,nbt={Item:{id:"minecraft:red_dye"}}] run data merge entity @s {Color:14b,Tags:["wasd.color_changed"]}
execute if entity @e[type=item,tag=!wasd.validated,distance=..0.0001,sort=nearest,limit=1,nbt={Item:{id:"minecraft:black_dye"}}] run data merge entity @s {Color:15b,Tags:["wasd.color_changed"]}

execute if entity @s[tag=wasd.color_changed] run kill @e[type=item,tag=!wasd.validated,distance=..0.0001,sort=nearest,limit=1]
execute if entity @s[tag=wasd.color_changed] run tag @s remove wasd.color_changed


tag @e[type=item,tag=!wasd.validated,distance=..0.0001] add wasd.validated
