#recharging totem of undying
execute as @e[type=minecraft:shulker] at @s at @e[type=item,tag=!wasd.validated,distance=..1.5] run function wasd.shulker:set_color


