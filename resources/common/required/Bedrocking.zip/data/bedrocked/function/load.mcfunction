function wither:wither/toggle/tanimation2
schedule function bedrocked:range 5s