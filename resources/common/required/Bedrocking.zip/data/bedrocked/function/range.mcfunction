execute as @e[type=player] run attribute @s minecraft:block_interaction_range base set 5
schedule function bedrocked:range 5s replace